rootProject.name = "DavutTeknoloji4D"
include(":app")
