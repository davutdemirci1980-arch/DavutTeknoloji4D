
plugins {
    id("com.android.application")
    kotlin("android") version "1.9.0"
}

android {
    namespace = "com.davut.technology"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.davut.technology"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
}
